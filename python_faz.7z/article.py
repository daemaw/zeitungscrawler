from datetime import datetime

class Article:
    def __init__(self, category, date, title, is_premium):
        self.category = category
        self.date = datetime.strptime(date, '%Y-%m-%dT%H:%M:%S%z')
        self.title = title
        self.is_premium = is_premium
        
        
    
        
