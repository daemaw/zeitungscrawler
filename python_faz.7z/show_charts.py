import matplotlib.pyplot as plt
import numpy as np


def show_premium(article_count, premium_count):
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = ['Gratis', 'Paywall']
    explode = (0.1, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')
    sizes = [article_count-premium_count, premium_count]

    fig, ax = plt.subplots()
    ax.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
           shadow=True, startangle=90)
    ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    plt.title('FAZ Anteil kostenpflichtiger Artikel')
    
    plt.savefig('premium.png')
    
def show_categories(categories):
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = []
    sizes = []
    
    for category in categories:
        labels.append(category[0])
        sizes.append(category[1])


    fig, ax = plt.subplots()
    width = 0.75
    ind = np.arange(len(sizes))
    ax.barh(ind, sizes, width, color='blue')
    ax.set_yticks(ind+width/2)
    ax.set_yticklabels(labels)
    
    plt.xticks(np.arange(min(sizes), max(sizes)+1, 1.0))
    plt.tight_layout()
    plt.title('FAZ Artikel Kategorien absolut')
    plt.subplots_adjust(top=0.88)
    plt.savefig('categories.png')
    
    
def show_most_words(most_words):
     # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = []
    sizes = []
    
    for word in reversed(most_words[:20]):
        labels.append(word[0])
        sizes.append(word[1])


    fig, ax = plt.subplots()
    width = 0.75
    ind = np.arange(len(sizes))
    ax.barh(ind, sizes, width, color='orange')
    ax.set_yticks(ind+width/2)
    ax.set_yticklabels(labels)
    plt.title('FAZ Artikeltitel Schlagwörter (gefiltert)')
    
    plt.xticks(np.arange(min(sizes), max(sizes)+1, 1.0))
    plt.tight_layout()
    plt.savefig('mostWord.png')