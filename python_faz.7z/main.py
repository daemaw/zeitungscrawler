import re
from collections import Counter

from datetime import datetime

from bs4 import BeautifulSoup
import requests

import show_charts

from article import Article



class FAZCrawler:
    url = 'https://www.faz.net/aktuell/'
    articles = []
    
    def __init__(self):
        res = requests.get(self.url)
        parsed_html = BeautifulSoup(res.text, features='lxml')
        
        self.get_articles(parsed_html, '.tsr-Base_ContentLink')
        
        
    def get_articles(self, parsed_html, selector):
        for article in parsed_html.select(selector):
            url = article.get('href')
            if url and url.startswith('https://www.faz.net/aktuell/'):
                article_link = requests.get(url)
                parsed_html = BeautifulSoup(article_link.text, features='lxml')
                category_url = parsed_html.select_one('.nvg-Breadcrumb_Link')
                title = parsed_html.select_one('.atc-HeadlineText')
                date = parsed_html.select_one('.atc-MetaTime')
                is_premium = article.get('data-is-premium')
                
                if category_url and title and date and is_premium:
                    category_text = category_url.select_one('span').text
                    

                    self.articles.append(Article(category_text, date.get('datetime'), title.text, is_premium == 'true'))
                
        
    def get_categories(self):
        all_categories = []
        for article in self.articles:
                all_categories.append(article.category)
            
        
        return Counter(all_categories).most_common()
        
        
    def get_premium(self):
        count_premium = 0
        for article in self.articles:
            if article.is_premium:
                count_premium += 1
        return count_premium
    
    def get_titles(self):
        titles = []
        for article in self.articles:
            title = article.title
            # Erlaube nur Buchstaben, Umlaute und Leerzeichen in den Strings
            titles.append(re.sub('[^a-zA-Z üäöÜÄÖß]+', '', title))
        return titles

    def count_word(self, word):
        count = 0
        for title in self.get_titles():
            if word.lower() in title.lower():
                count += 1
        return count

    
    def most_word(self):
        words = []
        blacklist = self.load_blacklist('blacklist.txt')
        for title in self.get_titles():
            for word in title.lower().split(' '):
                if word and word not in blacklist:
                    words.append(word)
            
        return Counter(words).most_common()
    
    def load_blacklist(self, filepath):
        with open(filepath, 'r', encoding='utf-8') as blacklist_file:
            words = blacklist_file.read().split(',')
            
        return [word.lower() for word in words]
    
    def write_csv(self, filepath):
        with open(filepath, 'w', encoding='utf-8') as csv_faz:
            for article in self.articles:
                date_format = datetime.strftime(article.date, '%Y-%m-%d %H:%M:%S')
                csv_faz.write(
                    f'{article.category},{date_format},{article.title},{article.is_premium}\n'
                )
            csv_faz.truncate(csv_faz.tell()-1)
                
        



if __name__ == '__main__':
    crawler = FAZCrawler()
    #print(len(crawler.articles))
    #show_charts.show_premium(len(crawler.articles), crawler.get_premium())
    #show_charts.show_categories(crawler.get_categories())
    #show_charts.show_most_words(crawler.most_word())
    crawler.write_csv('csv_faz.csv')
    
